
import { useEffect, useState } from 'react'

import {
  getUserPosts,
  deletePost,
  mediaUrl,
  type Post
} from '../../service/postService'

import './PostList.css'

type PostListProps = {
  userId: number
  own?: boolean
}

export default function PostList({
  userId,
  own = false
}: PostListProps) {

  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false

    setLoading(true)
    setError('')

    getUserPosts(userId)
      .then(data => {
        if (!cancelled) {
          setPosts(data)
        }
      })
      .catch(e => {
        if (!cancelled) {
          setError(e.message)
        }
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false)
        }
      })

    return () => {
      cancelled = true
    }
  }, [userId])

  async function remove(postId: number) {
    if (!window.confirm('Delete this post?')) {
      return
    }

    try {
      await deletePost(postId)

      setPosts(current =>
        current.filter(
          post => post.postId !== postId
        )
      )
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : 'Delete failed'
      )
    }
  }

  if (loading) {
    return <p>Loading posts...</p>
  }

  return (
    <div className="creative-post-list">

      {error && (
        <p role="alert">{error}</p>
      )}

      {!error && posts.length === 0 && (
        <p>No posts yet.</p>
      )}

      {posts.map(post => (
        <article
          key={post.postId}
          className="creative-post-card"
        >

          <header>
            <strong>@{post.username}</strong>

            <small>
              {new Date(
                post.createdAt
              ).toLocaleString()}
            </small>

            {own && (
              <button
                type="button"
                onClick={() => remove(post.postId)}
              >
                Delete
              </button>
            )}
          </header>

          {post.caption && (
            <p>{post.caption}</p>
          )}

          {post.media.map(media => (
            media.mediaType === 'IMAGE' ? (
              <img
                key={media.mediaId}
                src={mediaUrl(media.viewUrl)}
                alt={media.originalFileName}
                loading="lazy"
              />
            ) : (
              <a
                key={media.mediaId}
                href={mediaUrl(media.viewUrl)}
                target="_blank"
                rel="noreferrer"
              >
                {media.originalFileName}
              </a>
            )
          ))}

        </article>
      ))}

    </div>
  )
}
